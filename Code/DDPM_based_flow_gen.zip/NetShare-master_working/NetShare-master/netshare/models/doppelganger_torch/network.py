import numpy as np
import torch
from torch.autograd import Variable
import torch.nn.functional as F
from netshare.utils import Output, OutputType, Normalization


class AttrDiscriminator(torch.nn.Module):
    def __init__(
        self,
        input_attribute_dim,
        num_layers=5,
        num_units=200,
        scope_name="attr_discriminator",
        *args,
        **kwargs
    ):
        super(AttrDiscriminator, self).__init__()
        self.scope_name = scope_name

        layers = []
        layer_num_units = input_attribute_dim
        for _ in range(num_layers - 1):
            layers.append(torch.nn.Linear(layer_num_units, num_units))
            layers.append(torch.nn.ReLU())
            layer_num_units = num_units

        layers.append(torch.nn.Linear(layer_num_units, 1))
        self.attr_disc = torch.nn.Sequential(*layers)
        self._reinitialize()

    def _reinitialize(self):
        """
        Tensorflow/Keras-like initialization
        """
        for name, p in self.named_parameters():

            if "weight" in name:
                torch.nn.init.xavier_uniform_(p.data)
            elif "bias" in name:
                p.data.fill_(0)

    def forward(self, input_attribute):
        input_ = torch.flatten(input_attribute, start_dim=1)

        return self.attr_disc(input_)


class Discriminator(torch.nn.Module):
    def __init__(
        self,
        max_sequence_len,
        input_feature_dim,
        input_attribute_dim,
        num_layers=5,
        num_units=200,
        scope_name="discriminator",
        *args,
        **kwargs
    ):
        super(Discriminator, self).__init__()
        self.scope_name = scope_name

        self.time_cond_layer = torch.nn.Linear(1, 100)
        self.input_dim = max_sequence_len * input_feature_dim + 2*input_attribute_dim +100
        #print(self.input_dim)
        
        layers = []
        layer_num_units = self.input_dim
        for _ in range(num_layers - 1):
            layers.append(torch.nn.Linear(layer_num_units, num_units))
            layers.append(torch.nn.ReLU())
            layer_num_units = num_units

        layers.append(torch.nn.Linear(layer_num_units, 1))
        self.disc = torch.nn.Sequential(*layers)
        self._reinitialize()

    def _reinitialize(self):
        """
        Tensorflow/Keras-like initialization
        """
        for name, p in self.named_parameters():
            if "weight" in name:
                torch.nn.init.xavier_uniform_(p.data)
            elif "bias" in name:
                p.data.fill_(0)

    def forward(self, input_feature, input_attribute,time_cond,packed_real_attribute_tp1):

        input_feature = torch.flatten(input_feature, start_dim=1, end_dim=2)
        input_attribute = torch.flatten(input_attribute, start_dim=1)
        time_cond_processed = self.time_cond_layer(time_cond.unsqueeze(1))

        #print(input_feature.shape, "checking sizeing", input_attribute.shape)
        input_ = torch.cat((input_feature, input_attribute,time_cond_processed,packed_real_attribute_tp1), dim=1)
       # print(input_.shape, self.input_dim)
        out= self.disc(input_)
        #print("first run complete >>> ")
        return out

class DoppelGANgerGenerator(torch.nn.Module):
    def __init__(
        self,
        attr_latent_dim,
        feature_latent_dim,
        feature_outputs,
        attribute_outputs,
        real_attribute_mask,
        sample_len,
        attribute_num_units=100,
        attribute_num_layers=3,
        feature_num_units=100,
        feature_num_layers=1,
        batch_size=100,
        use_adaptive_rolling=True,
        device="cpu",
        scope_name="doppelganger_generator",
        *args,
        **kwargs
    ):
        super(DoppelGANgerGenerator, self).__init__()
        self.scope_name = scope_name
        self.device = device

        self.feature_out_dim = np.sum([t.dim for t in feature_outputs])
        self.feature_outputs = feature_outputs
        self.attribute_out_dim = np.sum([t.dim for t in attribute_outputs])
        self.attribute_outputs = attribute_outputs
        self.feature_num_layers = feature_num_layers
        self.feature_num_units = feature_num_units
        self.batch_size = batch_size
        self.use_adaptive_rolling = use_adaptive_rolling

        self.time_cond_layer = torch.nn.Linear(1, attr_latent_dim)
        self.given_attribute_x_layer1 = torch.nn.Linear(165, 100)
        self.given_attribute_x_layer2 = torch.nn.Linear(100, 5)

        self.given_attribute_layer1 = torch.nn.Linear(165, 100)
        self.given_attribute_layer2 = torch.nn.Linear(100, 5)

        self.real_attribute_outputs = []
        self.real_attribute_out_dim = 0
        for i in range(len(attribute_outputs)):
            if real_attribute_mask[i]:
                self.real_attribute_outputs.append(self.attribute_outputs[i])
                self.real_attribute_out_dim += attribute_outputs[i].dim


        for i in range(len(real_attribute_mask) - 1):
            if real_attribute_mask[i] == False and real_attribute_mask[i + 1] == True:
                raise Exception("Real attribute should come first")

        # Define generator without the output layer for real attributes
        layers = []
        num_layer_units = attr_latent_dim
        for i in range(attribute_num_layers - 1):
            layers.append(torch.nn.Linear(num_layer_units, attribute_num_units))
            layers.append(torch.nn.ReLU())
            layers.append(
                torch.nn.BatchNorm1d(
                    num_features=attribute_num_units, eps=1e-5, momentum=0.9
                )
            )
            num_layer_units = attribute_num_units

        self.real_attribute_gen_without_last_layer = torch.nn.Sequential(
            *layers)

        # Define the output layer of the real attributes generator
        self.real_attribute_gen_last_layer = torch.nn.ModuleList()
        for i in range(len(self.real_attribute_outputs)):
            attr_out_layer = [
                torch.nn.Linear(
                    num_layer_units, self.real_attribute_outputs[i].dim)]
            if self.real_attribute_outputs[i].type_ == OutputType.DISCRETE:
                attr_out_layer.append(torch.nn.Softmax(dim=-1))
            else:
                if (
                    self.real_attribute_outputs[i].normalization
                    == Normalization.ZERO_ONE
                ):
                    attr_out_layer.append(torch.nn.Sigmoid())
                else:
                    attr_out_layer.append(torch.nn.Tanh())
            self.real_attribute_gen_last_layer.append(
                torch.nn.Sequential(*attr_out_layer)
            )


        # Define the feature generator
        self.lstm_module = torch.nn.LSTM(
            self.real_attribute_out_dim
            + feature_latent_dim,
            self.feature_num_units,
            self.feature_num_layers,
            batch_first=True,
        )

        self.feature_gen_last_layer = torch.nn.ModuleList()
        feature_len = len(self.feature_outputs)
        num_layer_units = self.feature_num_units
        for i in range(feature_len * sample_len):

            feature_out_layer = [
                torch.nn.Linear(
                    num_layer_units, self.feature_outputs[i % feature_len].dim
                )
            ]
            if self.feature_outputs[i % feature_len].type_ == OutputType.DISCRETE:
                feature_out_layer.append(torch.nn.Softmax(dim=-1))
            else:
                if (
                    self.feature_outputs[i % feature_len].normalization
                    == Normalization.ZERO_ONE
                ):
                    feature_out_layer.append(torch.nn.Sigmoid())
                else:
                    feature_out_layer.append(torch.nn.Tanh())

            self.feature_gen_last_layer.append(
                torch.nn.Sequential(*feature_out_layer))

        self._reinitialize()

    def _reinitialize(self):
        """
        Tensorflow/Keras-like initialization
        """
        for name, p in self.named_parameters():
            if "lstm" in name:
                if "weight_ih" in name:
                    torch.nn.init.xavier_uniform_(p.data)
                elif "weight_hh" in name:
                    torch.nn.init.orthogonal_(p.data)
                elif "bias_ih" in name:
                    p.data.fill_(0)
                    # Set forget-gate bias to 1
                    n = p.size(0)
                    p.data[(n // 4): (n // 2)].fill_(1)
                elif "bias_hh" in name:
                    p.data.fill_(0)
            elif "linear" in name:
                if "weight" in name:
                    torch.nn.init.xavier_uniform_(p.data)
                elif "bias" in name:
                    p.data.fill_(0)

    def zero_grad(self, set_to_none: bool = True) -> None:
        r"""Sets gradients of all model parameters to zero. See similar function
        under :class:`torch.optim.Optimizer` for more context.

        Args:
            set_to_none (bool): instead of setting to zero, set the grads to None.
                See :meth:`torch.optim.Optimizer.zero_grad` for details.
        """

        for p in self.parameters():
            if p.grad is not None:
                if set_to_none:
                    p.grad = None
                else:
                    if p.grad.grad_fn is not None:
                        p.grad.detach_()
                    else:
                        p.grad.requires_grad_(False)
                    p.grad.zero_()

    def forward(
        self,
        real_attribute_noise,
        feature_input_noise,
        h0,
        c0,
        given_attribute_x=None,
        time_cond=None,
        given_attribute=None,
        given_attribute_discrete=None,
    ):
        # Shape of feature_input_noise is [batch_size, sample_time, latent_dim]
        # Shape of real_attribute_noise is [batch_size, latent_dim]
        feature_input_noise = feature_input_noise.cuda()
        #print(real_attribute_noise.size(),real_attribute_noise.size(),
            # feature_input_noise.size(),
            # h0.size(),
            # c0.size())

        if given_attribute_x is not None and time_cond is not None:
            #print(given_attribute_x.shape, real_attribute_noise.shape, feature_input_noise.shape, h0.shape, c0.shape, time_cond.shape)
            given_attribute_x_processed = self.given_attribute_x_layer1(given_attribute_x)
            given_attribute_x_processed=self.given_attribute_x_layer2(given_attribute_x_processed)
            time_cond_processed = self.time_cond_layer(time_cond.unsqueeze(1))
            real_attribute_noise = real_attribute_noise + given_attribute_x_processed + time_cond_processed

        elif given_attribute is not None and given_attribute_discrete is not None:
            given_attribute=given_attribute.cuda()
            given_attribute_discrete=given_attribute_discrete.cuda()
            given_attribute_processed = self.given_attribute_layer1(given_attribute)
            given_attribute_processed=self.given_attribute_layer2(given_attribute_processed)

            print(given_attribute_processed.device)
            real_attribute_noise = real_attribute_noise + given_attribute_processed

        
        attribute = []
        attribute_discrete = []

        # Calculate the forwarding of attribute generator
        real_attribute = []
        real_attribute_discrete = []
        real_attribute_gen_tmp = self.real_attribute_gen_without_last_layer(
            real_attribute_noise
        )

        for attr_layer in self.real_attribute_gen_last_layer:
            attr_sub_output = attr_layer(real_attribute_gen_tmp)
            if isinstance(attr_layer[-1], torch.nn.Softmax):
                attr_sub_output_discrete = F.one_hot(
                    torch.argmax(attr_sub_output, dim=1),
                    num_classes=attr_sub_output.shape[1],
                )
            else:
                attr_sub_output_discrete = attr_sub_output
            real_attribute.append(attr_sub_output)
            real_attribute_discrete.append(attr_sub_output_discrete)
        real_attribute = torch.cat(real_attribute, dim=1)
        real_attribute_discrete = torch.cat(
            real_attribute_discrete, dim=1).detach()

        attribute.append(real_attribute)
        attribute_discrete.append(real_attribute_discrete)

        attribute = torch.cat(attribute, dim=1)
        attribute_discrete = torch.cat(attribute_discrete, dim=1)


        # Calculate the forwarding of the feature generator
        attribute_ = torch.unsqueeze(attribute_discrete, dim=1)
        feature_input_ = attribute_.expand(
            -1, feature_input_noise.shape[1], -1
        ).detach()

        feature_input_=feature_input_.cuda()
        #print(attribute_.size(), feature_input_noise.shape[1],"es")
        feature_input = torch.cat((feature_input_, feature_input_noise), dim=2)
        
    
        feature_rnn_output_tmp, _ = self.lstm_module(
            feature_input, (h0, c0)
        )
        #print(feature_rnn_output_tmp.size(), feature_input.size(),"es")
        feature = []
        for feature_layer in self.feature_gen_last_layer:
            feature_sub_output = feature_layer(feature_rnn_output_tmp)
            feature.append(feature_sub_output)
        feature = torch.cat(feature, dim=2)
            #print(feature.size(),"es")
        ###########
        #print(feature.size())
        feature = torch.reshape(
            feature,
            (
                feature.shape[0],
                int(feature.shape[1] * feature.shape[2] / self.feature_out_dim),
                self.feature_out_dim,
            ),
        )
        #print(feature.size())
        return attribute, attribute_discrete, feature
